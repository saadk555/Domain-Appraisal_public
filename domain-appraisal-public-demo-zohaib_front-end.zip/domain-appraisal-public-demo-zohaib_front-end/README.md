<h1 align="center" id="title">Pekisa</h1>

<p id="description">This project is for the testing purpose.</p>

<h2>🛠️ Installation Steps:</h2>

<p>1. Open the Terminal and Run This Command</p>

```
git clone https://github.com/MuhammadZohaib28/Pekisa.git
```

<p>2. After Cloning Run this Command</p>

```
npm install
```

<p>3. After installing npm Run this Command</p>

```
npm run dev
```

  
  
<h2>💻 Built with</h2>

Technologies used in the project:

*   ReactJS
*   TailwindCSS

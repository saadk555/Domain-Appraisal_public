import React from 'react'

const RenewTransfer = () => {
  return (
    <div>RenewTransfer</div>
  )
}

export default RenewTransfer